#!/usr/bin/env python3
import argparse, socket, threading, time, random

FRAME_LEN = 16
PRE, SYNC = b"\xAA\xAA", b"\x55\x55"
SAT_ID = 0xA1

STATE = {"mode": 0x00, "beacon_on": True, "seq": 0}

clients = []
jam_duty = 0.0
lock = threading.Lock()

def crc16(data: bytes) -> int:
    crc = 0xFFFF
    for b in data:
        crc ^= b
        for _ in range(8):
            if crc & 1: crc = (crc >> 1) ^ 0xA001
            else: crc >>= 1
    return crc & 0xFFFF

def make_beacon():
    global STATE
    STATE["seq"] = (STATE["seq"] + 1) % 256
    payload = PRE + SYNC + bytes([SAT_ID, STATE["mode"], STATE["seq"], 0x01]) + b"\x00" * 6
    c = crc16(payload).to_bytes(2, "big")
    return payload + c

def handle_client(conn, addr):
    global jam_duty
    with conn:
        while True:
            data = conn.recv(1024)
            if not data:
                break
            # Simulated jamming
            if random.random() < jam_duty:
                continue
            if len(data) != FRAME_LEN:
                continue
            if crc16(data[:-2]) != int.from_bytes(data[-2:], "big"):
                continue
            sat, mode, seq, cmd = data[4], data[5], data[6], data[7]
            if sat != SAT_ID:
                continue
            with lock:
               for c in clients[:]:
                  try: c.sendall(data)
                  except: 
                    try: clients.remove(c)
                    except ValueError: pass
            if cmd == 0x02:
                STATE["beacon_on"] = False
                print(f"[EMU] RX CMD=BEACON_OFF seq={seq:02X} -> beacon_on=False")
            elif cmd == 0x03:
                STATE["beacon_on"] = True
                print(f"[EMU] RX CMD=BEACON_ON seq={seq:02X} -> beacon_on=True")
            elif cmd == 0x04:
                old = STATE["mode"]
                STATE["mode"] = mode
                print(f"[EMU] RX CMD=SET_MODE seq={seq:02X} mode {old:02X}->{mode:02X}")
            else:
                print(f"[EMU] RX CMD=0x{cmd:02X} (ignored)")

def beacon_task(interval):
    while True:
        time.sleep(interval)
        if not STATE["beacon_on"]:
            continue
        pkt = make_beacon()
        if random.random() < jam_duty:
            continue
        with lock:
            for c in clients[:]:
                try:
                    c.sendall(pkt)
                except Exception:
                    try: clients.remove(c)
                    except ValueError: pass

def control_server(control_port):
    global jam_duty
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("127.0.0.1", control_port))
    srv.listen(5)
    print(f"[EMU] Control on 127.0.0.1:{control_port}")
    while True:
        conn, _ = srv.accept()
        with conn:
            data = conn.recv(128).decode("utf-8").strip()
            if not data: continue
            parts = data.split()
            if parts[0].upper() == "JAM" and len(parts) == 2:
                try:
                    duty = float(parts[1])
                    duty = max(0.0, min(1.0, duty))
                    jam_duty = duty
                    msg = f"OK JAM {jam_duty}\n"
                except ValueError:
                    msg = "ERR bad duty\n"
                conn.sendall(msg.encode("utf-8"))
                print(f"[EMU] JAM duty set to {jam_duty}")
            elif parts[0].upper() == "STATUS":
                msg = f"STATUS mode={STATE['mode']:02X} beacon_on={int(STATE['beacon_on'])} jam={jam_duty}\n"
                conn.sendall(msg.encode("utf-8"))
            else:
                conn.sendall(b"ERR unknown\n")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=5000)
    ap.add_argument("--control-port", type=int, default=5001)
    ap.add_argument("--beacon", type=int, default=2)
    args = ap.parse_args()

    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("127.0.0.1", args.port))
    srv.listen(5)
    print(f"[EMU] Data on 127.0.0.1:{args.port}")

    threading.Thread(target=beacon_task, args=(args.beacon,), daemon=True).start()
    threading.Thread(target=control_server, args=(args.control_port,), daemon=True).start()

    while True:
        conn, addr = srv.accept()
        clients.append(conn)
        threading.Thread(target=handle_client, args=(conn, addr), daemon=True).start()

if __name__ == "__main__":
    main()

