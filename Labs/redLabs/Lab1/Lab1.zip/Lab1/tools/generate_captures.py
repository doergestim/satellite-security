#!/usr/bin/env python3
"""
Regenerate synthetic BFSK I/Q passes for Lab 1.
Writes complex float32 binary files at 48 kS/s to ./assets/
"""
import json, math, struct, binascii, hashlib, random
from pathlib import Path
import numpy as np

SYNCWORD = 0x1ACFFC1D
FS = 48000
RB = 1200
SPB = FS // RB
F_DEV = 2000.0

def crc16_ccitt(data: bytes, init=0xFFFF):
    import binascii
    return binascii.crc_hqx(data, init)

def pack_u32_be(x): return x.to_bytes(4, "big")
def pack_u16_be(x): return x.to_bytes(2, "big")
def pack_u8(x): return bytes([x & 0xFF])

def bits_from_bytes(b: bytes):
    for byte in b:
        for i in range(8):
            yield (byte >> (7 - i)) & 1

def modulate_bfsk(bits, fs=FS, spb=SPB, fdev=F_DEV, snr_db=18.0, seed=1337):
    rng = np.random.default_rng(seed)
    out = np.zeros(len(bits)*spb, dtype=np.complex64)
    t = np.arange(spb)/fs
    for i, bit in enumerate(bits):
        f = fdev if bit==1 else -fdev
        out[i*spb:(i+1)*spb] = np.exp(1j*2*np.pi*f*t).astype(np.complex64)
    if snr_db is not None:
        snr_linear = 10**(snr_db/10.0)
        noise_var = 1.0/(2*snr_linear)
        noise = (rng.normal(0, math.sqrt(noise_var), out.shape) + 1j*rng.normal(0, math.sqrt(noise_var), out.shape)).astype(np.complex64)
        out = out + noise
    return out

def bytes_from_bits(bits):
    out = bytearray()
    for i in range(0, len(bits), 8):
        byte = 0
        for j in range(8):
            if i+j < len(bits):
                byte = (byte << 1) | (bits[i+j] & 1)
            else:
                byte <<= 1
        out.append(byte)
    return bytes(out)

def make_packet(version:int, seq:int, ptype:int, payload:dict):
    import json
    pay = json.dumps(payload, separators=(",", ":")).encode()
    header = pack_u32_be(SYNCWORD) + pack_u8(version) + pack_u16_be(seq) + pack_u8(ptype) + pack_u16_be(len(pay))
    crc_input = pack_u8(version) + pack_u16_be(seq) + pack_u8(ptype) + pack_u16_be(len(pay)) + pay
    crc = crc16_ccitt(crc_input)
    return header + pay + pack_u16_be(crc)

def assemble_bitstream(packets, preamble_bits=256, inter_pkt_bits=64):
    bits = [i & 1 for i in range(preamble_bits)]
    for i, pkt in enumerate(packets):
        bits.extend(list(bits_from_bytes(pkt)))
        if i != len(packets) - 1:
            bits.extend([0]*inter_pkt_bits)
    return np.array(bits, dtype=np.uint8)

def auth_tag(epoch:int, sat_name:str):
    return hashlib.sha1(f"{epoch}{sat_name}-BLUE".encode()).hexdigest()[:8]

def main():
    ROOT = Path(__file__).resolve().parents[1]
    ASSETS = ROOT / "assets"
    ASSETS.mkdir(parents=True, exist_ok=True)
    SAT_NAME = "ODYSSEY-1"
    CALLSIGN = "ODYSYS"
    epoch_hint = 1713371337
    AUTH_HINT = auth_tag(epoch_hint, SAT_NAME)

    seq = 1
    pkts_pass1 = []
    pkts_pass1.append(make_packet(1, seq, 0x01, {
        "sat": SAT_NAME, "cs": CALLSIGN, "epoch": epoch_hint, "battery": 7.6, "temp": 21.4,
        "asm": "1ACFFC1D", "note": "ASM present every frame", "hint": "color? BLUE",
    })); seq += 1
    pkts_pass1.append(make_packet(1, seq, 0x02, {
        "subsys": {"adcs":"ok", "comms":"ok", "payload":"idle"},
        "pos": {"lat": 38.246, "lon": 21.735, "alt_km": 530},
        "status": "nominal; FLAG1{downlink_decoded}"
    })); seq += 1
    pkts_pass1.append(make_packet(1, seq, 0x01, {
        "sat": SAT_NAME, "cs": CALLSIGN, "epoch": epoch_hint, "battery": 7.5, "temp": 21.1,
        "msg": "auth_tag=? sha1(epoch+sat+'-BLUE')[:8]"
    })); seq += 1

    bits1 = assemble_bitstream(pkts_pass1, preamble_bits=256, inter_pkt_bits=96)
    iq1 = modulate_bfsk(bits1, snr_db=18.0, seed=1337)
    (ASSETS/"pass_01.iq").write_bytes(iq1.astype(np.complex64).tobytes())
    (ASSETS/"pass_01.json").write_text(json.dumps({"samplerate": 48000, "format":"complex_float32", "description":"BFSK baseband synthetic capture – Pass 01"}, indent=2))

    pkts_pass2 = []
    pkts_pass2.append(make_packet(1, seq, 0x01, {
        "sat": SAT_NAME, "epoch": epoch_hint+93, "battery": 7.4, "temp": 20.9,
        "ad": "look for TYPE=3 with field 'auth' that equals sha1(epoch+sat+'-BLUE')[:8]"
    })); seq += 1
    pkts_pass2.append(make_packet(1, seq, 0x10, {  # pretend "CSP data"
        "csp": {"src": 10, "dst": 1, "port": 4},
        "tlm": {"panel_v": 4.1, "panel_i": 290, "rx_rssi": -92},
        "ack": f"CMD ACK: SET_MODE CAL auth={AUTH_HINT}; reward: FLAG2{{protocol_reversed}}"
    })); seq += 1

    bits2 = assemble_bitstream(pkts_pass2, preamble_bits=192, inter_pkt_bits=64)
    iq2 = modulate_bfsk(bits2, snr_db=10.0, seed=1338)
    (ASSETS/"pass_02.iq").write_bytes(iq2.astype(np.complex64).tobytes())
    (ASSETS/"pass_02.json").write_text(json.dumps({"samplerate": 48000, "format":"complex_float32", "description":"BFSK baseband synthetic capture – Pass 02 (noisier)"}, indent=2))

    print("Regenerated captures under", ASSETS)

if __name__ == "__main__":
    main()
