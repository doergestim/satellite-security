#!/usr/bin/env python3
"""
Local "uplink gateway" for Lab 1.
This does NOT transmit any RF. It just validates a crafted command packet file against
the lab's fictional link-layer and prints an ACK + FLAG3 if correct.
Usage:
  python3 sat_gateway.py uplink.bin
"""
import sys, json, hashlib, binascii, struct
from pathlib import Path

SYNCWORD = 0x1ACFFC1D

def crc16_ccitt(data: bytes, init=0xFFFF):
    import binascii
    return binascii.crc_hqx(data, init)

def rd_u32_be(b, off): return int.from_bytes(b[off:off+4], "big")
def rd_u16_be(b, off): return int.from_bytes(b[off:off+2], "big")
def rd_u8(b, off): return b[off]

def parse_packet(pkt: bytes):
    if len(pkt) < 4+1+2+1+2+2: raise ValueError("too short")
    if rd_u32_be(pkt,0) != SYNCWORD: raise ValueError("bad sync")
    ver = rd_u8(pkt,4); seq = rd_u16_be(pkt,5); ptype = rd_u8(pkt,7); ln = rd_u16_be(pkt,8)
    pay = pkt[10:10+ln]
    if len(pay) != ln: raise ValueError("truncated payload")
    crc = rd_u16_be(pkt, 10+ln)
    calc = crc16_ccitt(pkt[4:10+ln])
    if crc != calc: raise ValueError("bad crc")
    return ver, seq, ptype, pay

def auth_tag(epoch:int, sat_name:str):
    return hashlib.sha1(f"{epoch}{sat_name}-BLUE".encode()).hexdigest()[:8]

def main():
    if len(sys.argv) != 2:
        print("Usage: python3 sat_gateway.py uplink.bin")
        sys.exit(2)
    data = Path(sys.argv[1]).read_bytes()
    ver, seq, ptype, pay = parse_packet(data)
    if ptype != 0x03:
        raise ValueError("expected TYPE=3 (command)")
    j = json.loads(pay.decode())
    required = {"cmd", "epoch", "sat", "auth"}
    if not required.issubset(set(j.keys())):
        raise ValueError(f"missing fields; need {required}")
    if j["cmd"] != "SET_MODE" or j.get("mode") != "CAL":
        raise ValueError("incorrect command or mode")
    tag = auth_tag(int(j["epoch"]), j["sat"])
    if j["auth"] != tag:
        raise ValueError("bad auth tag")
    # Success!
    flag = "FLAG3{uplink_forged_locally}"
    print(f"ACK: MODE=CAL accepted; FLAG: {flag}")

if __name__ == "__main__":
    main()
