#!/usr/bin/env python3
import argparse, csv, itertools
def head(path, n):
    with open(path) as f:
        r=csv.reader(f); return list(itertools.islice(r, n+1))
if __name__=="__main__":
    ap=argparse.ArgumentParser(); ap.add_argument("--out", default="outputs"); ap.add_argument("-n", type=int, default=5); a=ap.parse_args()
    for name in ("real_pointing.csv","forged_pointing.csv","pointing_error.csv"):
        p=f"{a.out}/{name}"; print(f"== {name} ==")
        for row in head(p,a.n): print(",".join(row))
        print()
