#!/usr/bin/env python3
import argparse

def compute_checksum(line68: str) -> str:
    s = 0
    for ch in line68:
        if ch.isdigit():
            s += int(ch)
        elif ch == '-':
            s += 1
    return str(s % 10)

def pad68(s: str) -> str:
    return (s + " " * 68)[:68]

def apply_forge(l1, l2, dn=0.0, draan=0.0):
    # Adjust RAAN and mean motion fields
    raan = float(l2[17:25])
    n = float(l2[52:63])
    raan += draan
    n += dn
    l2n = list(pad68(l2))
    l2n[17:25] = f"{raan:8.4f}"
    l2n[52:63] = f"{n:11.8f}"
    l2n = "".join(l2n) + compute_checksum("".join(l2n))
    l1n = pad68(l1) + compute_checksum(pad68(l1))
    return l1n, l2n

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="infile", required=True)
    ap.add_argument("--out", dest="outfile", required=True)
    ap.add_argument("--dn", type=float, default=0.0, help="delta mean motion")
    ap.add_argument("--draan", type=float, default=0.0, help="delta RAAN (deg)")
    args = ap.parse_args()

    with open(args.infile) as f:
        lines = [l.strip() for l in f if l.strip()]
    name, l1, l2 = lines[0], lines[1], lines[2]

    l1f, l2f = apply_forge(l1, l2, dn=args.dn, draan=args.draan)
    with open(args.outfile, "w") as f:
        f.write(f"{name}-FORGED\n{l1f}\n{l2f}\n")
    print(f"Wrote forged TLE to {args.outfile}")
