#!/usr/bin/env python3
import argparse, csv, datetime
import matplotlib.pyplot as plt
def read(path):
    with open(path) as f:
        r=csv.DictReader(f); rows=list(r)
    ts=[datetime.datetime.fromisoformat(x["iso"]) for x in rows]
    return ts, rows
if __name__=="__main__":
    ap=argparse.ArgumentParser(); ap.add_argument("--out", default="outputs"); a=ap.parse_args()
    ts_r,rp=read(f"{a.out}/real_pointing.csv")
    ts_f,fp=read(f"{a.out}/forged_pointing.csv")
    ts_e,er=read(f"{a.out}/pointing_error.csv")
    import matplotlib.pyplot as plt
    plt.figure(); plt.plot(ts_r,[float(x["az_deg"]) for x in rp],label="real az"); plt.plot(ts_f,[float(x["az_deg"]) for x in fp],label="forged az"); plt.legend(); plt.xlabel("time"); plt.ylabel("az (deg)"); plt.title("Azimuth vs time"); plt.show()
    plt.figure(); plt.plot(ts_r,[float(x["el_deg"]) for x in rp],label="real el"); plt.plot(ts_f,[float(x["el_deg"]) for x in fp],label="forged el"); plt.legend(); plt.xlabel("time"); plt.ylabel("el (deg)"); plt.title("Elevation vs time"); plt.show()
    plt.figure(); plt.plot(ts_e,[float(x["angular_error_deg"]) for x in er],label="total error"); plt.legend(); plt.xlabel("time"); plt.ylabel("angular error (deg)"); plt.title("Pointing error"); plt.show()
