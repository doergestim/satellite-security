#!/usr/bin/env python3
import os, json, argparse, math, csv
import jpype, jpype.imports

# ---------- JVM / Orekit init ----------
def start_jvm():
    if not jpype.isJVMStarted():
        cp = os.environ.get("CLASSPATH", "")
        jpype.startJVM(classpath=[p for p in cp.split(":") if p])

def setup_orekit():
    # Orekit 12.x: register data provider via DataContext
    from org.orekit.data import DataContext, DirectoryCrawler
    from java.io import File
    data_dir = os.environ.get("OREKIT_DATA_PATH", "/orekit-data")
    dm = DataContext.getDefault().getDataProvidersManager()
    dm.addProvider(DirectoryCrawler(File(data_dir)))

# ---------- I/O helpers ----------
def load_tle(path):
    with open(path,"r") as f:
        lines = [l.strip() for l in f if l.strip()]
    return lines[0], lines[1], lines[2]

def write_csv(path, headers, rows):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path,"w",newline="") as f:
        w = csv.writer(f)
        w.writerow(headers)
        w.writerows(rows)

# ---------- Propagation ----------
def propagate(name, l1, l2, start_iso, duration_min, step_s=10.0):
    from org.orekit.utils import IERSConventions
    from org.orekit.frames import FramesFactory
    from org.orekit.time import TimeScalesFactory, AbsoluteDate
    from org.orekit.propagation.analytical.tle import TLE, TLEPropagator
    from org.orekit.models.earth import ReferenceEllipsoid

    # Parse ISO "YYYY-MM-DDTHH:MM:SS"
    y,M,d,hh,mm,ss = map(int, start_iso.replace('T','-').replace(':','-').split('-'))
    utc = TimeScalesFactory.getUTC()
    start = AbsoluteDate(y,M,d,hh,mm,ss, utc)

    tle = TLE(l1, l2)
    prop = TLEPropagator.selectExtrapolator(tle)
    itrf = FramesFactory.getITRF(IERSConventions.IERS_2010, True)
    earth = ReferenceEllipsoid.getWgs84(itrf)

    dates, lla = [], []
    steps = int(duration_min*60/step_s)+1
    for i in range(steps):
        d = start.shiftedBy(i*step_s)
        state = prop.propagate(d)
        geod = earth.transform(state.getPVCoordinates(itrf).getPosition(), itrf, d)
        lat = math.degrees(geod.getLatitude())
        lon = math.degrees(geod.getLongitude())
        alt = geod.getAltitude()
        dates.append(d)
        lla.append((lat, lon, alt))
    return dates, lla

# ---------- Pointing (pure Python WGS-84) ----------
def pointing_series(lla_series, dates, gs_lat, gs_lon, gs_alt):
    # Compute az/el from GS to target using WGS-84 ECEF -> ENU
    a = 6378137.0
    f = 1/298.257223563
    e2 = f*(2-f)

    def geodetic_to_ecef(lat_deg, lon_deg, h_m):
        lat = math.radians(lat_deg); lon = math.radians(lon_deg)
        s, c = math.sin(lat), math.cos(lat)
        N = a / math.sqrt(1 - e2*s*s)
        x = (N + h_m) * c * math.cos(lon)
        y = (N + h_m) * c * math.sin(lon)
        z = (N*(1 - e2) + h_m) * s
        return x, y, z

    def ecef_to_enu(dx, dy, dz, lat0_deg, lon0_deg):
        lat0 = math.radians(lat0_deg); lon0 = math.radians(lon0_deg)
        slat, clat = math.sin(lat0), math.cos(lat0)
        slon, clon = math.sin(lon0), math.cos(lon0)
        e = -slon*dx + clon*dy
        n = -slat*clon*dx - slat*slon*dy + clat*dz
        u =  clat*clon*dx + clat*slon*dy + slat*dz
        return e, n, u

    x0, y0, z0 = geodetic_to_ecef(gs_lat, gs_lon, gs_alt)
    az_list, el_list = [], []
    for (lat, lon, alt) in lla_series:
        xs, ys, zs = geodetic_to_ecef(lat, lon, alt)
        e, n, u = ecef_to_enu(xs-x0, ys-y0, zs-z0, gs_lat, gs_lon)
        az = math.degrees(math.atan2(e, n));  az = az if az >= 0 else az + 360.0
        el = math.degrees(math.atan2(u, math.hypot(e, n)))
        az_list.append(az); el_list.append(el)
    return az_list, el_list

# ---------- Forgery ----------
def apply_forge_to_tle(l1, l2, dn=0.0, draan_deg=0.0):
    # Adjust RAAN (cols 18-25) and mean motion (cols 53-63) using fixed-width fields.
    def put(line,a,b,val):
        L=list(line); s=str(val)
        for i,ch in enumerate(s): L[a-1+i]=ch
        return "".join(L)
    raan = float(l2[17:25]); n = float(l2[52:63])
    raan += draan_deg; n += dn
    l2n = put(l2,18,25,f"{raan:8.4f}")
    l2n = put(l2n,53,63,f"{n:11.8f}")

    def cks(line):
        s=0
        for ch in line[:68]:
            if ch.isdigit(): s+=int(ch)
            elif ch=='-': s+=1
        return s%10
    l1 = l1[:-1] + str(cks(l1))
    l2n = l2n[:-1] + str(cks(l2n))
    return l1, l2n

# ---------- Main ----------
if __name__=="__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--tle", required=True)
    ap.add_argument("--gs", required=True)
    ap.add_argument("--forge-offsets", default="")
    ap.add_argument("--out", default="outputs")
    args = ap.parse_args()

    # parse offsets
    dn = 0.0; draan = 0.0
    if args.forge_offsets:
        for kv in args.forge_offsets.split(","):
            if not kv.strip(): continue
            k,v = kv.split("=")
            if k.strip()=="dn": dn = float(v)
            if k.strip()=="draan": draan = float(v)

    start_jvm(); setup_orekit()

    name,l1,l2 = load_tle(args.tle)
    gs = json.load(open(args.gs))

    dates, lla = propagate(name,l1,l2, gs["start_iso"], gs["duration_min"])
    az, el = pointing_series(lla, dates, gs["lat_deg"], gs["lon_deg"], gs["alt_m"])
    write_csv(os.path.join(args.out,"real_track.csv"), ["iso","lat_deg","lon_deg","alt_m"],
              [(str(d),lat,lon,alt) for d,(lat,lon,alt) in zip(dates, lla)])
    write_csv(os.path.join(args.out,"real_pointing.csv"), ["iso","az_deg","el_deg"],
              [(str(d),a,e) for d,a,e in zip(dates, az, el)])

    l1f, l2f = apply_forge_to_tle(l1,l2, dn=dn, draan_deg=draan)
    dates_f, lla_f = propagate(name,l1f,l2f, gs["start_iso"], gs["duration_min"])
    az_f, el_f = pointing_series(lla_f, dates_f, gs["lat_deg"], gs["lon_deg"], gs["alt_m"])
    write_csv(os.path.join(args.out,"forged_track.csv"), ["iso","lat_deg","lon_deg","alt_m"],
              [(str(d),lat,lon,alt) for d,(lat,lon,alt) in zip(dates_f, lla_f)])
    write_csv(os.path.join(args.out,"forged_pointing.csv"), ["iso","az_deg","el_deg"],
              [(str(d),a,e) for d,a,e in zip(dates_f, az_f, el_f)])

    # Pointing error
    def wrap180(x): return (x+180.0)%360.0 - 180.0
    rows=[]
    for d,a,e,af,ef in zip(dates,az,el,az_f,el_f):
        da = wrap180(af - a); de = ef - e
        ang = math.degrees(math.acos(max(-1.0,min(1.0,
            math.sin(math.radians(e))*math.sin(math.radians(ef)) +
            math.cos(math.radians(e))*math.cos(math.radians(ef))*math.cos(math.radians(da))
        ))))
        rows.append((str(d), da, de, ang))
    write_csv(os.path.join(args.out,"pointing_error.csv"),
              ["iso","delta_az_deg","delta_el_deg","angular_error_deg"], rows)
    print("Wrote CSVs in", args.out)
