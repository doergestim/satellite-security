#!/usr/bin/env python3
import argparse, csv, time
if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--pointing", required=True)
    ap.add_argument("--rate_hz", type=float, default=2.0)
    a=ap.parse_args()
    rows=list(csv.DictReader(open(a.pointing)))
    print("Naive antenna controller sim:", a.pointing)
    for row in rows:
        az=float(row["az_deg"]); el=float(row["el_deg"]); t=row["iso"]
        print(f"[{t}] SET az={az:.2f} el={el:.2f}")
        time.sleep(1.0/a.rate_hz)
