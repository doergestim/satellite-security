from flask import Flask, request, jsonify, render_template_string
from flask_cors import CORS
import json, binascii, hashlib

app=Flask(__name__); CORS(app)
SYNC=0x1ACFFC1D
state={"mode":"NOMINAL","seq":0,"authtag":"-"}
HTML='''<!doctype html><title>ODYSSEY-1 Control</title>
<style>body{font-family:system-ui,Arial;background:#0b1220;color:#e8f0ff;margin:2rem}
.card{background:#111827;border:1px solid #223;width:740px;padding:1rem;border-radius:.75rem;box-shadow:0 0 30px #0003}
.kv{display:grid;grid-template-columns:auto 1fr;gap:.5rem 1rem}label{opacity:.7}code{background:#0e1726;padding:.2rem .35rem;border-radius:.35rem}</style>
<h1>ODYSSEY‑1 Control</h1>
<div class=card><div class=kv>
<label>Mode</label><div>{{mode}}</div>
<label>Last Seq</label><div>{{seq}}</div>
<label>Last Auth</label><div><code>{{authtag}}</code></div>
<label>Hint</label><div>sha1(str(epoch)+sat+"-BLUE")[:8]</div>
</div><p>POST forged uplink to <code>/uplink</code> as file field <code>packet</code> or JSON <code>{"hex":"..."}</code>.</p></div>'''
def crc16_ccitt(b, init=0xFFFF): return binascii.crc_hqx(b, init)
def auth_tag(epoch:int, sat:str): return hashlib.sha1(f"{epoch}{sat}-BLUE".encode()).hexdigest()[:8]
def parse(pkt:bytes):
    if len(pkt)<12: raise ValueError("too short")
    if int.from_bytes(pkt[0:4],"big")!=SYNC: raise ValueError("bad sync")
    ver=pkt[4]; seq=int.from_bytes(pkt[5:7],"big"); ptype=pkt[7]; ln=int.from_bytes(pkt[8:10],"big")
    pay=pkt[10:10+ln]; 
    if len(pay)!=ln: raise ValueError("truncated")
    crc=int.from_bytes(pkt[10+ln:10+ln+2],"big"); calc=crc16_ccitt(pkt[4:10+ln])
    if crc!=calc: raise ValueError("bad crc")
    return ver,seq,ptype,json.loads(pay.decode())
@app.route("/") 
def home(): return render_template_string(HTML, **state)
@app.route("/uplink", methods=["POST"])
def uplink():
    raw=None
    if "packet" in request.files: raw=request.files["packet"].read()
    else:
        j=request.get_json(silent=True)
        if j and "hex" in j:
            try: raw=bytes.fromhex(j["hex"])
            except: return jsonify({"ok":False,"err":"bad hex"}),400
    if not raw: return jsonify({"ok":False,"err":"missing packet"}),400
    try:
        ver,seq,ptype,body=parse(raw)
        if ptype!=0x03: return jsonify({"ok":False,"err":"wrong type"}),400
        need={"cmd","mode","epoch","sat","auth"}
        if not need.issubset(body.keys()): return jsonify({"ok":False,"err":f"missing {sorted(need)}"}),400
        tag=auth_tag(int(body["epoch"]), body["sat"])
        if body["auth"]!=tag: return jsonify({"ok":False,"err":"bad auth"}),403
        state["mode"]=body.get("mode","NOMINAL"); state["seq"]=seq; state["authtag"]=tag
        return jsonify({"ok":True,"ack":f"SET_MODE {state['mode']} accepted","flag":"FLAG_TAKEOVER{mode_set_CAL}"})
    except Exception as e:
        return jsonify({"ok":False,"err":str(e)}),400
if __name__=="__main__": app.run(host="0.0.0.0", port=5000, threaded=True)
