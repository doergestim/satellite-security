#!/usr/bin/env python3
import json, struct, binascii, hashlib
SYNC=0x1ACFFC1D
def crc16_ccitt(b, init=0xFFFF): return binascii.crc_hqx(b, init)
def pkt(ver, seq, ptype, payload:dict):
    pay=json.dumps(payload,separators=(',',':')).encode()
    hdr=struct.pack('>IBHBH', SYNC, ver, seq, ptype, len(pay))
    crc_in=struct.pack('>BHBH', ver, seq, ptype, len(pay))+pay
    crc=crc16_ccitt(crc_in)
    return hdr+pay+struct.pack('>H',crc)
# Fill from your decode:
epoch=1713372600
sat="ODYSSEY-1"
auth=hashlib.sha1(f"{epoch}{sat}-BLUE".encode()).hexdigest()[:8]
uplink=pkt(1, 4242, 0x03, {"cmd":"SET_MODE","mode":"CAL","epoch":epoch,"sat":sat,"auth":auth})
open('uplink.bin','wb').write(uplink)
print("uplink.bin written")
