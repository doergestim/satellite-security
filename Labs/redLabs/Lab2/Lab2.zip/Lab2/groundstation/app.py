from flask import Flask, request, jsonify, Response
from flask_cors import CORS
import json, time, threading, hashlib
app=Flask(__name__); CORS(app)
telemetry={"sat":"ODYSSEY-1","epoch":1713372000,"battery":7.60,"temp":21.0,"mode":"NOMINAL","rx_rssi":-85,"counter":0}
lock=threading.Lock()
HTML='''<!doctype html><title>ODYSSEY-1 Ground Station</title>
<style>body{font-family:system-ui,Arial;background:#0b1220;color:#e8f0ff;margin:2rem}
.card{background:#111827;border:1px solid #223;width:700px;padding:1rem;border-radius:.75rem;box-shadow:0 0 30px #0003}
.kv{display:grid;grid-template-columns:auto 1fr;gap:.5rem 1rem}label{opacity:.7}</style>
<h1>ODYSSEY‑1 Ground Station</h1><div class=card><div id=tlm class=kv></div>
<p>Live feed via SSE at <code>/stream</code>. Insecure endpoints: <code>/login</code>, <code>/cmd</code>, <code>/ingest</code>.</p></div>
<script>function row(k,v){return `<label>${k}</label><div>${v}</div>`}
const tlm=document.getElementById('tlm');const es=new EventSource('/stream');
es.onmessage=(e)=>{const j=JSON.parse(e.data);tlm.innerHTML=Object.entries(j).map(([k,v])=>row(k,v)).join('')};</script>'''
def sse():
    while True:
        time.sleep(1.0)
        with lock:
            telemetry["counter"]+=1; data=dict(telemetry)
        yield f"data: {json.dumps(data)}\n\n"
@app.route("/")
def home(): return HTML
@app.route("/stream")
def stream(): return Response(sse(), mimetype="text/event-stream")
@app.route("/login", methods=["POST"])
def login():
    user=request.form.get("user",""); pw=request.form.get("pass","")
    if user=="admin": return jsonify({"ok":True,"msg":"login success (intentionally weak)"})
    return jsonify({"ok":False,"msg":"unknown user"}), 401
@app.route("/cmd", methods=["POST"])
def cmd():
    j=request.get_json(force=True, silent=True) or {}; target=j.get("mode","NOMINAL")
    s="x"*100000
    for _ in range(1000): s=hashlib.sha256(s.encode()).hexdigest()
    with lock: telemetry["mode"]=target
    return jsonify({"ok":True,"applied":target})
@app.route("/ingest", methods=["POST"])
def ingest():
    j=request.get_json(force=True, silent=True) or {}
    with lock: telemetry.update(j)
    return jsonify({"ok":True,"ingested":True})
if __name__=="__main__": app.run(host="0.0.0.0", port=5000, threaded=True)
